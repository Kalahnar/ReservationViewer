package Viewer;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;


public class AboutInformation extends javax.swing.JFrame {
    public static final int HEIGHT = 225;
    public static final int WIDTH =  600;  
    public static final int FONT_SIZE = 20;
    public static final int COMPONENT_HEIGHTWIDTH = 300;
    public static final int IMAGE_SIZE = 15;
    public static final String description = "Information like authors, date created"
            + "hours took to make, version etc... ";
    
    public  void main(String[] args) 
    {
         JFrame aboutFrame = new JFrame();
        aboutFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        aboutFrame.setLocationRelativeTo(null);
        aboutFrame.setVisible(true);
    }
    public AboutInformation()
    {
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);  
        setFileMenu();
        setTextPanel();
        setButtonPanel();
        add(textPanel,BorderLayout.CENTER);
        setTitle("About");
        add(buttonPanel, BorderLayout.SOUTH);
        
        
    }
    
    public void setFileMenu()
    {
        menuSelector = new JMenuBar();
        
        closeItem  = new JMenuItem("Close");
        
        fileMenu = new JMenu("File");       
        fileMenu.add(closeItem);
        menuSelector.add(fileMenu);
        setJMenuBar(menuSelector);
//        closeItem.addActionListener(listener);
        closeItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeItemActionPerformed(evt);
            }
        });
       
        
    }
    
  //sets the text area and the description of the program 
    public void setTextPanel()
    {
        //Once we figure out the text make sure GUI is resizible(false);
        textPanel = new JPanel();
        setLayout(new FlowLayout());
        textArea = new JTextArea(15,40);
        add(textArea);
        textArea.setEditable(false);
        textArea.setText(description);
         
    
    }
    public void setButtonPanel()
    {
        buttonPanel = new JPanel();
        setLayout (new FlowLayout());
        closeButton = new JButton("Close");
        add(closeButton);
              
    }
    
    
//     ActionListener listener = new ActionListener() 
//    {
//    /**
//     * Description: Overrides an actionPerformed method in order to create
//     * an event when the file items are clicked it will performed said action.
//     * @param event - check to see if action occurred
//     * 
//     */
//    @Override
//    public void actionPerformed(ActionEvent event)
//    {
//        if(event.getSource() == closeItem)
//        {
//
//            this.actionPerformed(eve);
//            System.out.println("Error");
//        }
//       
//    }
//    };
    
    private void closeItemActionPerformed(java.awt.event.ActionEvent evt) {                                          
        
        this.dispose();
        
        
    }
     
     
     
    
    //JFrame aboutFrame;
    JMenuBar menuSelector;
    JMenu fileMenu;
    JMenuItem closeItem;
    JPanel textPanel;
    JTextArea textArea;
    JPanel buttonPanel;
    JButton closeButton;
}
