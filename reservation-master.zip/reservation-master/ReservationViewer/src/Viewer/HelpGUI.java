package Viewer;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;


public class HelpGUI extends JFrame {
    public static final int HEIGHT = 225;
    public static final int WIDTH =  600;  
    public static final int FONT_SIZE = 20;
    public static final int COMPONENT_HEIGHTWIDTH = 300;
    public static final int IMAGE_SIZE = 15;
    public static final String description = "How to navigate the program ";
    
    public  void main(String[] args) 
    {
       JFrame help = new HelpGUI();
        help.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        help.setLocationRelativeTo(null);
        help.setVisible(true);
    }
    public HelpGUI()
    {
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);  
        setFileMenu();
        setTextPanel();
        setButtonPanel();
        setTitle("About");
        add(textPanel,BorderLayout.NORTH);
        add(buttonPanel,BorderLayout.SOUTH);
        
    }
    
    public void setFileMenu()
    {
        menuSelector = new JMenuBar();
        
        closeItem  = new JMenuItem("Close");
        
        fileMenu = new JMenu("File");       
        fileMenu.add(closeItem);
        menuSelector.add(fileMenu);
        setJMenuBar(menuSelector);
        closeItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeItemActionPerformed(evt);
            }
        });
        
    }
    
  //sets the text area and the description of the program 
    public void setTextPanel()
    {
        //Once we figure out the text make sure GUI is resizible(false);
        textPanel = new JPanel();
        setLayout(new FlowLayout());
        textArea = new JTextArea(15,40);
        add(textArea);
        textArea.setEditable(false);
        textArea.setText(description);
    
    
    }
    
    public void setButtonPanel()
    {
        buttonPanel = new JPanel();
        setLayout (new FlowLayout());
        closeButton = new JButton("Close");
        add(closeButton);
              
    }
    
    
    private void closeItemActionPerformed(java.awt.event.ActionEvent evt) {                                          
        
        this.dispose();
        
        
    }
    
    
    JMenuBar menuSelector;
    JMenu fileMenu;
    JMenuItem closeItem;
    JPanel textPanel;
    JTextArea textArea;
    JPanel buttonPanel;
    JButton closeButton;
}
